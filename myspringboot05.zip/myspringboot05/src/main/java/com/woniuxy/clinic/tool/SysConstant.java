package com.woniuxy.clinic.tool;

public class SysConstant {
	/**
     * 系统菜单根节点ID
     */
    public static final Long MEUNS_ROOT_ID = 0L;
}
