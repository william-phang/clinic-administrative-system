package com.woniuxy.clinic.exception;

public class StaffException extends RuntimeException {

	public StaffException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public StaffException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public StaffException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public StaffException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public StaffException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
}
